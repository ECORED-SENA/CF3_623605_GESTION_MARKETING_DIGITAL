function ExecuteScript(strId)
{
  switch (strId)
  {
      case "66j1gnfLtKZ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

